package com.animal;

public class Fish extends Animal {

	String fishName;
	double length;
	int lifespanYears;

	public Fish(String skinColor, String species, String animalName, int numberOfLegs, double length, int lifespanYears, String fishName) {
		super(skinColor, species, animalName, numberOfLegs);
		this.length = length;
		this.lifespanYears = lifespanYears;
		this.fishName = fishName;
		}

	public void setLength(double length) {
		this.length = length;
	}
	
	public void setLifeSpanYears(int lifespanYears) {
		this.lifespanYears = lifespanYears;
	}
	
	public double getLength() {
		return this.length;
	}
	
	public int getLifeSpanYears() {
		return this.lifespanYears;
	}

	public void setFishName (String fishName) {
		this.fishName = fishName;
	}
	
	public String getFishName() {
		return this.fishName;
	}

	
	public void maxDepth (double distance) {
		System.out.println("This fish can swim " + distance + " below the ocean");
	}
}
