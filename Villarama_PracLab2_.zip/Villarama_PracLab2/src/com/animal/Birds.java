package com.animal;

public class Birds extends Fish{

	String birdName;
	double wingSpan;
	double talonSize;
	
	public Birds (String skinColor, String species, String animalName, int numberOfLegs, double length, int lifespanYears, String fishName, double wingSpan, double talonSize, String birdName) {
		super(skinColor, species, animalName, numberOfLegs, length, lifespanYears, fishName);
		this.wingSpan = wingSpan;
		this.talonSize = talonSize;
		this.birdName = birdName;
		}
	
	public void setWingSpan(double wingSpan) {
		this.wingSpan = wingSpan;
	}
	
	public void setTalonSize(double talonSize) {
		this.talonSize = talonSize;
	}
	
	public void setBirdName(String birdName) {
		this.birdName = birdName;
	}
	
	public String getBirdName() {
		return this.birdName;
	}
	
	public double getWingSpan() {
		return this.wingSpan;
	}

	public double getTalonSize() {
		return this.talonSize;
	}		
	
	public void maxAltitude (double flightDistance) {
		System.out.println(birdName + " can fly " + flightDistance + " ft. above the ground");
	}
	
}
