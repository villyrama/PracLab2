package com.animal;

public class Test {

	public static void main(String[] args) {
		Animal anm1 = new Animal("Striped Orange and Black", "Felidae", "Tiger", 4);
			System.out.println("Name of the Animal: " + anm1.getAnimalName());
			System.out.println("Animal Species: " + anm1.getSpecies());
			System.out.println("Number of legs: " + anm1.getNumberOfLegs());
			System.out.println("Color of the skin: " + anm1.getSkinColor());
		
		System.out.println();
		Fish amph = new Fish("Gray", "Sumatran", "Rhinoceros", 4, 4.2, 200, "Bowhead Whale");
		
			System.out.println("The " + amph.getSkinColor() + ", " + amph.getSpecies() + " " + amph.getAnimalName() + " is critically endangered");
			System.out.println("The name of the animal is the " + amph.getFishName() + ". The length of the fish is " + amph.getLength() + " meters");
			System.out.println("It can live up to " + amph.getLifeSpanYears() + " years!" );

			amph.maxDepth(2000);
	
		System.out.println();
		Birds avian = new Birds("Brown", "Elephant", "Wooly Mammoth", 4, 18, 40, "Megalodon", 2.3, 2, "American Eagle" );
			System.out.println(avian.getSkinColor() + " of color, and the ancestors of the " + avian.getSpecies() + ", the " + avian.getAnimalName() + " once roamed the Earth");
			System.out.println("It spans up to " + avian.getLength() + " meters, and can live up to " 
			+ avian.getLifeSpanYears() + " years, the " + avian.getFishName() + " once ruled the seas 2.6 million years ago");
			
			System.out.println();
			System.out.println("Another one on the list is the famous " + avian.getBirdName() + ". Its wingspan stretches " +  avian.getWingSpan() + " meters which is taller than your average-size human.");
			System.out.println("Its talons spanning up to " + avian.getTalonSize() + " inches in length is used to hunt animals for its sustenance");
			
			avian.maxAltitude(10000);
	
	}
			
}
