package com.animal;

public class Animal {
	String animalName;
	String species;
	String skinColor;
	int numberOfLegs;
	
	public Animal (String skinColor, String species, String animalName, int numberOfLegs) {
		this.skinColor = skinColor;
		this.numberOfLegs =  numberOfLegs;
		this.animalName = animalName;
		this.species = species;
		}
	
	public void setSkinColor(String skinColor) {
		this.skinColor = skinColor;
	}
	
	public void setNumberOfLegs(int numberOfLegs) {
		this.numberOfLegs = numberOfLegs;
	}

	public void setAnimalName(String animalName) {
		this.animalName = animalName;
	}	
	
	public void setSpecies(String species) {
		this.species = species;
	}
	
	public String getSkinColor() {
		return this.skinColor;
	}
	
	public int getNumberOfLegs() {
		return this.numberOfLegs;
	}
	
	public String getAnimalName() {
		return this.animalName;
	}
	
	public String getSpecies() {
		return this.species;
	}
}
